const Users = require('../models/users');

exports.getall = async function(req, res) {
  try {
    var returnedUsers = await Users.find({});
    console.log(returnedUsers);
    res.render('admin', { user: returnedUsers });
  } catch (err) {
    console.log(err);
  }

exports.create = async function(req, res) {
  let newUser = new Users({
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    email: req.body.email,
    password: req.body.password,
    role: req.body.role,
  });

  try {
    await newUser.save();
    res.redirect('/admin');
  } catch (err) {
    console.log(err);
  }
};

exports.update_get = async function(req, res) {
  var newUser = await Users.findOne({ _id: req.query.id });
  res.render('update', newUser);
};

exports.update = async function(req, res) {
  const updateData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    email: req.body.email,
    password: req.body.password,
    role: req.body.role,
  };

  var result = await Users.findOneAndUpdate({ _id: req.body.id }, updateData);
  res.redirect('/admin');
};

exports.delete = async function(req, res) {
  console.log(req.query);
  await Users.findOneAndDelete({ _id: req.query.id });
  res.redirect('/admin');
};

};