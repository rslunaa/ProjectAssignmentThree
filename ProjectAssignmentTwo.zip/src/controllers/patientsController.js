const patients = require('../models/patients');

exports.getall = async function(req, res) {
  try {
    var returnedPatients = await patients.find({});
    console.log(returnedPatients);
    res.render('dashboard', { patients: returnedPatients });
  } catch (err) {
    console.log(err);
  }

exports.create = async function(req, res) {
  let newPatients = new patients({
    creatorId: req.body.creatorId,
    CreatorName: req.body.CreatorName,
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    birthdate: req.body.birthdate,
    zipcode: req.body.zipcode,
    state: req.body.state,
    phoneNumber: req.body.phoneNumber,
    createDate: req.body.createDate,
    insuranceType: req.body.insuranceType,
    testType: req.body.testType,
    doctorService: req.body.doctorService,
    labName: req.body.labName,
    sampleStatus: req.body.sampleStatus,
  });

  try {
    await newPatients.save();
    res.redirect('/dashboard');
  } catch (err) {
    console.log(err);
  }
};

exports.update_get = async function(req, res) {
  var newPatients = await patients.findOne({ _id: req.query.id });
  res.render('updatePatient', newPatients);
};

exports.update = async function(req, res) {
  const updateData = {
    creatorId: req.body.creatorId,
    CreatorName: req.body.CreatorName,
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    birthdate: req.body.birthdate,
    zipcode: req.body.zipcode,
    state: req.body.state,
    phoneNumber: req.body.phoneNumber,
    createDate: req.body.createDate,
    insuranceType: req.body.insuranceType,
    testType: req.body.testType,
    doctorService: req.body.doctorService,
    labName: req.body.labName,
    sampleStatus: req.body.sampleStatus,
  };

  var result = await patients.findOneAndUpdate({ _id: req.body.id }, updateData);
  res.redirect('/dashboard');
};

exports.delete = async function(req, res) {
  console.log(req.query);
  await patients.findOneAndDelete({ _id: req.query.id });
  res.redirect('/dashboard');
};
};