var express = require('express');
var router = express.Router();
const usersController = require('../controllers/usersController.js');
const authMiddleware = require('../middleware/auth');


router.get('/', authMiddleware.ensureAuthenticated, function(req, res, next) {
  if (req.user.role !== 'Admin') {
    return res.status(403).send('Access denied');
  }
  usersController.getall(req, res);
});

router.get('/create', authMiddleware.ensureAuthenticated, function(req, res, next) {
  res.render('create');
});

router.post('/create', authMiddleware.ensureAuthenticated, function (req, res, next) {
  usersController.create(req, res)
});


router.get('/update', authMiddleware.ensureAuthenticated, function(req, res, next) {
  usersController.update_get(req, res);
});

router.post('/update', authMiddleware.ensureAuthenticated, function(req, res, next) {
  usersController.update(req, res);
});

router.get('/delete', authMiddleware.ensureAuthenticated, function(req, res, next) {
  usersController.delete(req, res);
});

module.exports = router;