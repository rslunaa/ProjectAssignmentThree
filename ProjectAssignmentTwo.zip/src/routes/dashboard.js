var express = require('express');
var router = express.Router();
const patientsController = require('../controllers/patientsController.js');
const authMiddleware = require('../middleware/auth');

router.get('/', authMiddleware.ensureAuthenticated, function(req, res, next) {
  patientsController.getall(req, res);
});

router.get('/createPatient', authMiddleware.ensureAuthenticated, function(req, res, next) {
  res.render('createPatient');
});

router.post('/createPatient', authMiddleware.ensureAuthenticated, function (req, res, next) {
  patientsController.create(req, res)
});

router.get('/updatePatient', authMiddleware.ensureAuthenticated, function(req, res, next) {
  patientsController.update_get(req, res);
  
});

router.post('/updatePatient', authMiddleware.ensureAuthenticated, function(req, res, next) {
  patientsController.update(req, res);
});

router.get('/delete', authMiddleware.ensureAuthenticated, function(req, res, next) {
  patientsController.delete(req, res);
});



module.exports = router;