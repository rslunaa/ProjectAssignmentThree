function ensureAuthenticated(req, res, next) {
  console.log("ensureAuthenticated middleware called");
  // if user is authenticated in the session, carry on 
 if (req.isAuthenticated()) {
    console.log("user is authenticated");
    return next();
 }

   //if they aren't redirect them to the home page
console.log("user is not authenticated - redirecting to home page");
res.redirect('/');
}

module.exports = {
  ensureAuthenticated: ensureAuthenticated,
}